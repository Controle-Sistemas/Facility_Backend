"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var __1 = __importDefault(require(".."));
var ModeloSysApiConf = /** @class */ (function () {
    function ModeloSysApiConf() {
    }
    ModeloSysApiConf.prototype.getSysApiConf = function (res) {
        try {
            __1.default.query('SELECT * FROM sysapiconf', function (err, results) {
                if (err) {
                    res.status(500).send({
                        message: err
                    });
                }
                else {
                    res.status(200).send({
                        message: 'SysApiConf listados com sucesso',
                        data: results
                    });
                }
            });
        }
        catch (error) {
            console.error(error);
        }
    };
    ModeloSysApiConf.prototype.getSysApiConfById = function (id, res) {
        try {
            __1.default.query('SELECT * FROM sysapiconf WHERE id = ?', [id], function (err, results) {
                if (err) {
                    res.status(500).send({
                        message: err
                    });
                }
                else {
                    res.status(200).send({
                        message: 'SysApiConf listado com sucesso',
                        data: results
                    });
                }
            });
        }
        catch (error) {
            console.error(error);
        }
    };
    ModeloSysApiConf.prototype.createSysApiConf = function (sysApiConf, res) {
        try {
            __1.default.query('INSERT INTO sysapiconf SET ?;', [sysApiConf], function (err, results) {
                if (err) {
                    res.status(500).send({
                        message: err
                    });
                }
                else {
                    res.status(200).send({
                        message: 'SysApiConf criado com sucesso',
                        data: results
                    });
                }
            });
        }
        catch (error) {
            console.error(error);
        }
    };
    ModeloSysApiConf.prototype.editSysApiConf = function (id, sysApiConf, res) {
        try {
            __1.default.query('UPDATE sysapiconf SET ? WHERE id = ?', [sysApiConf, id], function (err, results) {
                if (err) {
                    res.status(500).send({
                        message: err
                    });
                }
                else {
                    res.status(200).send({
                        message: 'SysApiConf editado com sucesso',
                        data: results
                    });
                }
            });
        }
        catch (error) {
            console.error(error);
        }
    };
    ModeloSysApiConf.prototype.deleteSysApiConf = function (id, res) {
        try {
            __1.default.query('DELETE FROM sysapiconf WHERE id = ?', [id], function (err, results) {
                if (err) {
                    res.status(500).send({
                        message: err
                    });
                }
                else {
                    res.status(200).send({
                        message: 'SysApiConf deletado com sucesso',
                        data: results
                    });
                }
            });
        }
        catch (error) {
            console.error(error);
        }
    };
    return ModeloSysApiConf;
}());
exports.default = new ModeloSysApiConf();
//# sourceMappingURL=sysapiconf.js.map