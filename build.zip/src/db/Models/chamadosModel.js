"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var __1 = __importDefault(require(".."));
var Chamados = /** @class */ (function () {
    function Chamados() {
    }
    Chamados.prototype.getDate = function () {
        var date = new Date();
        var ano = date.getFullYear();
        var mes = (date.getMonth() + 1).toString().length === 1 ? "0".concat(date.getMonth() + 1) : date.getMonth() + 1;
        var dia = date.getDate().toString().length === 1 ? "0".concat(date.getDate().toString()) : date.getDate().toString();
        var hora = date.getHours().toString() + ':' + date.getMinutes().toString() + ':' + date.getSeconds().toString();
        return "".concat(dia, "/").concat(mes, "/").concat(ano);
    };
    Chamados.prototype.isLate = function (data) {
        var date = this.getDate();
        data.forEach(function (item) {
            var _a = item.PREVISAO.split('-'), ano = _a[0], mes = _a[1], dia = _a[2];
            var dataPrevisao = "".concat(dia, "/").concat(mes, "/").concat(ano);
            if (item.ATIVO === 1 &&
                dataPrevisao < date) {
                item.STATUS = 5;
            }
        });
        return data;
    };
    Chamados.prototype.getAll = function (res) {
        var _this = this;
        try {
            __1.default.query("SELECT * FROM CHAMADOS", function (err, results) {
                if (err) {
                    console.log(err);
                    res.status(400).send(err);
                }
                else {
                    if (results.length > 0) {
                        results = _this.isLate(results);
                        res.status(200).send({
                            message: 'Chamados encontrados',
                            data: results
                        });
                    }
                    else {
                        res.status(404).send({
                            message: 'Nenhum chamado encontrado'
                        });
                    }
                }
            });
        }
        catch (error) {
            console.log(error);
            res.status(400).send(error);
        }
    };
    Chamados.prototype.getChamadoById = function (id, res) {
        var _this = this;
        try {
            __1.default.query("SELECT * FROM CHAMADOS WHERE ID = ".concat(id), function (err, results) {
                if (err) {
                    console.log(err);
                    res.status(400).send(err);
                }
                else {
                    if (results.length > 0) {
                        results = _this.isLate(results);
                        res.status(200).send({
                            message: 'Chamado encontrado',
                            data: results
                        });
                    }
                    else {
                        res.status(404).send({
                            message: 'Nenhum chamado encontrado'
                        });
                    }
                }
            });
        }
        catch (error) {
            console.log(error);
            res.status(400).send(error);
        }
    };
    Chamados.prototype.getChamadoBySector = function (sector, res) {
        var _this = this;
        try {
            __1.default.query("SELECT * FROM CHAMADOS WHERE SETOR = ".concat(sector), function (err, results) {
                if (err) {
                    console.log(err);
                    res.status(400).send(err);
                }
                else {
                    if (results.length > 0) {
                        results = _this.isLate(results);
                        res.status(200).send({
                            message: 'Chamado encontrado',
                            data: results
                        });
                    }
                    else {
                        res.status(404).send({
                            message: 'Nenhum chamado encontrado'
                        });
                    }
                }
            });
        }
        catch (error) {
            console.log(error);
            res.status(400).send(error);
        }
    };
    Chamados.prototype.getChamadoByStatus = function (status, res) {
        var _this = this;
        try {
            __1.default.query("SELECT * FROM CHAMADOS WHERE STATUS = ".concat(status), function (err, results) {
                if (err) {
                    console.log(err);
                    res.status(400).send(err);
                }
                else {
                    if (results.length > 0) {
                        results = _this.isLate(results);
                        res.status(200).send({
                            message: 'Chamado encontrado',
                            data: results
                        });
                    }
                    else {
                        res.status(404).send({
                            message: 'Nenhum chamado encontrado'
                        });
                    }
                }
            });
        }
        catch (error) {
            console.log(error);
            res.status(400).send(error);
        }
    };
    Chamados.prototype.getChamadoByInternalId = function (id, res) {
        var _this = this;
        try {
            __1.default.query("SELECT * FROM CHAMADOS WHERE IDINTERNO = ".concat(id), function (err, results) {
                if (err) {
                    console.log(err);
                    res.status(400).send(err);
                }
                else {
                    if (results.length > 0) {
                        results = _this.isLate(results);
                        res.status(200).send({
                            message: 'Chamado encontrado',
                            data: results
                        });
                    }
                    else {
                        res.status(404).send({
                            message: 'Nenhum chamado encontrado'
                        });
                    }
                }
            });
        }
        catch (error) {
            console.log(error);
            res.status(400).send(error);
        }
    };
    Chamados.prototype.getChamadoByUserId = function (id, res) {
        var _this = this;
        try {
            __1.default.query("SELECT * FROM CHAMADOS WHERE IDCLIENTE = ".concat(id), function (err, results) {
                if (err) {
                    console.log(err);
                    res.status(400).send(err);
                }
                else {
                    if (results.length > 0) {
                        results = _this.isLate(results);
                        res.status(200).send({
                            message: 'Chamado encontrado',
                            data: results
                        });
                    }
                    else {
                        res.status(404).send({
                            message: 'Nenhum chamado encontrado'
                        });
                    }
                }
            });
        }
        catch (error) {
            console.log(error);
            res.status(400).send(error);
        }
    };
    Chamados.prototype.getChamadoByInternalUsername = function (username, res) {
        var _this = this;
        try {
            __1.default.query("SELECT * FROM CHAMADOS WHERE INTERNORECEPTOR = '".concat(username, "'"), function (err, results) {
                if (err) {
                    console.log(err);
                    res.status(400).send(err);
                }
                else {
                    if (results.length > 0) {
                        results = _this.isLate(results);
                        res.status(200).send({
                            message: 'Chamado encontrado',
                            data: results
                        });
                    }
                    else {
                        console.log(results);
                        res.status(404).send({
                            message: 'Nenhum chamado encontrado'
                        });
                    }
                }
            });
        }
        catch (error) {
            console.log(error);
            res.status(400).send(error);
        }
    };
    Chamados.prototype.createChamado = function (chamadoData, res) {
        try {
            __1.default.query("INSERT INTO CHAMADOS SET ?", chamadoData, function (err, results) {
                if (err) {
                    console.log(err);
                    res.status(400).send(err);
                }
                else {
                    res.status(200).send({
                        message: 'Chamado criado com sucesso',
                        data: results
                    });
                }
            });
        }
        catch (error) {
            console.log(error);
            res.status(400).send(error);
        }
    };
    Chamados.prototype.updateChamado = function (id, chamadoData, res) {
        try {
            __1.default.query("UPDATE CHAMADOS SET ? WHERE ID = ".concat(id), chamadoData, function (err, results) {
                if (err) {
                    console.log(err);
                    res.status(400).send(err);
                }
                else {
                    res.status(200).send({
                        message: 'Chamado atualizado com sucesso',
                        data: results
                    });
                }
            });
        }
        catch (error) {
            console.log(error);
            res.status(400).send(error);
        }
    };
    Chamados.prototype.deleteChamado = function (id, res) {
        try {
            __1.default.query("DELETE FROM CHAMADOS WHERE ID = ".concat(id), function (err, results) {
                if (err) {
                    console.log(err);
                    res.status(400).send(err);
                }
                else {
                    res.status(200).send({
                        message: 'Chamado deletado com sucesso',
                        data: results
                    });
                }
            });
        }
        catch (error) {
            console.log(error);
            res.status(400).send(error);
        }
    };
    return Chamados;
}());
exports.default = new Chamados();
//# sourceMappingURL=chamadosModel.js.map