"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.API_PRODUCT_URL = exports.EXTERNAL_API_URL = void 0;
exports.EXTERNAL_API_URL = "https://apilicenca.controleautomacao.com.br/api/";
exports.API_PRODUCT_URL = 'http://192.95.42.179:9000/socket';
//# sourceMappingURL=urls.js.map