"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = __importDefault(require("express"));
var dashboard_1 = __importDefault(require("../requests/dashboard"));
var routes = express_1.default.Router();
routes.get('/', function (req, res) {
    var dashboardRequest = new dashboard_1.default('@20033038');
    var dataPromise = dashboardRequest.getRealTime();
    console.log('Entrou na Promisse');
    Promise.resolve(dataPromise).then(function (response) {
        if (response.error) {
            console.log('Entrou no If');
            res.status(400).json({
                message: "Erro!",
                data: response.data
            });
        }
        else {
            console.log(response);
            return res.status(200).json({ message: "Dados recuperados com sucesso", data: response });
        }
    });
});
routes.get('/real-time', function (req, res) {
    var dashboardRequest = new dashboard_1.default(req.params.clientId);
    var dataPromise = dashboardRequest.getRealTime();
    console.log('Entrou na Promisse');
    Promise.resolve(dataPromise).then(function (response) {
        if (response.error) {
            res.status(400).json({
                message: "Erro!",
                data: response.data,
            });
        }
        else {
            console.log(response);
            return res.status(200).json({ message: "Dados em tempo real recuperados com sucesso", data: response });
        }
    });
});
exports.default = routes;
//# sourceMappingURL=rotasRequisicaoDashboard.js.map