"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    expireIn: '2h',
    secret: "c428862a09042254bbc3108c2884063b9eab21b1458ad59f89c61d500fd7fef9",
};
//# sourceMappingURL=auth.js.map